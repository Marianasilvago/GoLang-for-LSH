package handlers

import (
	"log"
	"net/http"
	"strconv"
	"fmt"
)

type Fibo struct {
	l *log.Logger
}

// NewFibo - creates and return pointer struct Fibo
func NewFibo(l *log.Logger) *Fibo {
	return &Fibo{l}
}

// ServerHTTP - handles HTTP request to /fibo
func (f *Fibo) ServerHTTP(rw http.ResponseWriter, r *http.Request) {
	keys, ok := r.URL.Query()["n"] 
	if !ok || len(keys[0]) < 1 {
		f.l.Fatal("No value found in the url")
		http.Error(rw, "Unabled to parse input data", http.StatusBadRequest)
	}
	n, err := strconv.Atoi(keys[0])
	if err != nil {
		f.l.Fatal("Error parsing N value")
		http.Error(rw, "Unabled to parse input data", http.StatusBadRequest)
	}
	fibo := getFiboValue(n)
	response := []byte(fmt.Sprintf("%d",fibo))
	rw.Write(response)
}

func getFiboValue(n int) int {
	first := 0 ; second := 1
	if n == 0 {
	  return first
	} else if n <= 2 {
	  return second
	}
	for i := 2 ; i <= n; i++ {
	  second = second + first
	  first = second - first
	}
	return second
}